import pytest

class TestClass:
    def testMethod1(self):
        print("this is test method1")
    def testMethod2(self):
        print("this is test method2")

