# test_SignUp.PY

import pytest

class TestSignup:
    def test_SignupByEmail(self,setup):
        print("This is signup by email..")
        assert True == True

    def test_SignupFacebook(self,setup):
        print("This is signup by facebook..")
        assert True == True

    def test_SignupTwitter(self,setup):
        print("This is signup by twitter..")
        assert True == True